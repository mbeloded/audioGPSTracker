<?xml version="1.0"?>
<actions>

<!--
dmaf(function mainController(actions, instances, descriptors, entity, time, state, html) {
    function mainController(eventName, actionTime, eventProperties, actionProperties) {
        instances.vivify(actionProperties).onevent(eventName, actionTime, eventProperties);
    }
    actions.register("control", "mainController", mainController);

        //change these to edit the events that are sent out when increasing the speed
    var thresholdsUp = ["normal_speed_from_still", "medium_1_speed", "medium_2_speed", "high_1_speed","high_2_speed"],
        //change these to edit the event that are sent out when decreasing the speed
        thresholdsDown = ["idle", "normal_speed", "medium_1_speed", "medium_2_speed", "high_1_speed", "high_2_speed"],
        //change these to change the levels at whitch the events will be sent out
        thresholdLevels = [1, 20, 30, 40, 60],
        breaking = false,
        targetSpeed = 0,
        speedDifference = 0,
        tweening = false,
        previousSpeed = 0,
        previousFrameTime = 0,
        decrease = false,
        previousTurnDegree = 0,
        lastDispatchedSpeedLevel = "idle",
        transposeInLine = 0,
        dontStartSpeedPatternsBecauseWeAreTurning = false,
        bppStarted = false,
        currentBeat,
        currentBeatTime,
        speed_label = document.getElementById("speed_label");

    function updateSpeed() {
        previousSpeed = this.currentSpeed;
        var delta = this.tweenTime / (time.current - previousFrameTime),
            changeFactor = decrease ? (speedDifference / delta) * -1 : speedDifference / delta;
        this.currentSpeed += changeFactor;
        previousFrameTime = time.current;
        if ((!decrease && this.currentSpeed >= targetSpeed) || (decrease && this.currentSpeed <= targetSpeed)) {
            this.currentSpeed = targetSpeed;
            speed_label.innerHTML = parseInt(this.currentSpeed, 10);
            speed_label.style.color = this.currentSpeed > 0 ? "#86e0af" : "#ed7b79";
            this.dispatchEvent("_external:speed", {speed: this.currentSpeed});

                if(this.currentSpeed > 60){
                    //console.log("HIGH 2, NO MACRO");
                } else if(this.currentSpeed > 40){
                    this.dispatchEvent("synth_arp_1_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("drum_hit_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("drum_rolls_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("string_stac_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    //console.log("HIGH MACRO: " + (this.currentSpeed-40)/20);
                } else if (this.currentSpeed > 20){
                    this.dispatchEvent("synth_arp_1_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_bas_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_dist_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_arp_2_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("string_stac_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    //console.log("MEDIUM MACRO: " + (this.currentSpeed-20)/20);
                } else if (this.currentSpeed > 1){
                    this.dispatchEvent("synth_arp_1_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    this.dispatchEvent("synth_bas_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    this.dispatchEvent("string_stac_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    //console.log("LOW MACRO: " + (this.currentSpeed-1)/19);
                } else {
                    //console.log("IDLE, NO MACRO");
                }

            checkSpeed.call(this, this.currentSpeed, previousSpeed);
            tweening = false;
        } else {
            if (tweening) {
                checkSpeed.call(this, this.currentSpeed, previousSpeed);
                speed_label.innerHTML = parseInt(this.currentSpeed, 10);
                speed_label.style.color = this.currentSpeed > 0 ? "#86e0af" : "#ed7b79";
                this.dispatchEvent("_external:speed", {speed: this.currentSpeed});

                if(this.currentSpeed > 60){
                    //console.log("HIGH 2, NO MACRO");
                } else if(this.currentSpeed > 40){
                    this.dispatchEvent("synth_arp_1_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("drum_hit_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("drum_rolls_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    this.dispatchEvent("string_stac_dyn_fast_bus_macro", time.current, {value: (this.currentSpeed-40)/20});
                    //console.log("HIGH MACRO: " + (this.currentSpeed-40)/20);
                } else if (this.currentSpeed > 20){
                    this.dispatchEvent("synth_arp_1_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_bas_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_dist_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("synth_arp_2_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    this.dispatchEvent("string_stac_dyn_medium_bus_macro", time.current, {value: (this.currentSpeed-20)/20});
                    //console.log("MEDIUM MACRO: " + (this.currentSpeed-20)/20);
                } else if (this.currentSpeed > 1){
                    this.dispatchEvent("synth_arp_1_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    this.dispatchEvent("synth_bas_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    this.dispatchEvent("string_stac_dyn_normal_bus_macro", time.current, {value: (this.currentSpeed-1)/19});
                    //console.log("LOW MACRO: " + (this.currentSpeed-1)/19);
                } else {
                    //console.log("IDLE, NO MACRO");
                }

                html.raf(updateSpeed.bind(this));
            }
        }
    }

    function checkSpeed(currentSpeed, previousSpeed) {
        for (var i = 0; i < thresholdLevels.length; i++) {
            if (currentSpeed >= thresholdLevels[i] && previousSpeed < thresholdLevels[i]) {
                this.dispatchEvent(thresholdsUp[i]);
                //console.log("1: " + thresholdsUp[i]);
                lastDispatchedSpeedLevel = thresholdsUp[i];
                break;
            } else if (currentSpeed < thresholdLevels[i] && previousSpeed >= thresholdLevels[i]) {
                this.dispatchEvent(thresholdsDown[i]);
                //console.log("2: " + thresholdsDown[i]);
                lastDispatchedSpeedLevel = thresholdsDown[i];
                break;
            } else if (currentSpeed > thresholdLevels[i] && previousSpeed === 0) {
                //special case as everything below 0 is considered 0
                //so if the current speed is above 0 and previous is 0 we've gone from break to throttle
                this.dispatchEvent(thresholdsUp[i]);
                //console.log("3: " + thresholdsUp[i]);
                lastDispatchedSpeedLevel = thresholdsUp[i];
                breaking = false;
                break;
            } else if (currentSpeed === 0 && !breaking) {
                this.dispatchEvent(thresholdsDown[0]);
                //console.log("4: " + thresholdsDown[0]);
                lastDispatchedSpeedLevel = thresholdsDown[i];
                breaking = true;
                break;
            }
        }
    }

    descriptors.add({
        type: "control",
        id: "mainController",
        properties: [
            {
                name: "instanceId",
                type: "string"
            },
            {
                name: "triggers",
                type: "list"
            }
        ]
    });
    return entity.extend({
        type: {
            value: "control"
        },
        id: {
            value: "mainController"
        },
        init: {
            value: function() {
                this.currentSpeed = 0;
                this.tweenTime = 1;
            }
        },
        onevent: {
            value: function onevent(eventName, actionTime, eventProperties) {
                //console.log("onEvent: " + eventName)
                switch (eventName) {
                    case "metronome":
                        //console.log("BEAT: " + eventProperties.beat)
                        currentBeat = eventProperties.beat;
                        currentBeatTime = actionTime;
                        break;
                    case "do_transpose":
                        transposeInLine ++
                        if(transposeInLine === 4) {
                            transposeInLine = 0
                        }

                        switch(transposeInLine){
                            case 0:
                                this.dispatchEvent("transpose_0", actionTime);
                                break;
                            case 1:
                                this.dispatchEvent("transpose_3", actionTime);
                                break;
                            case 2:
                                this.dispatchEvent("transpose_minus_2", actionTime);
                                break;
                            case 3:
                                this.dispatchEvent("transpose_1", actionTime);
                                break;
                        }
                        break;
                    case "stop_notes":
                        //SORRY, this is a bad event name, it's actually used to stop overlapping notes.

                        core.dispatch("synth_pad", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("string_legato", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("string_stac", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("string_stac_dyn_normal", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("string_stac_dyn_medium", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("string_stac_dyn_fast", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("horn_legato", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("trombone_legato", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_bas", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_bas_dyn_normal", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_bas_dyn_medium", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_bas_dyn_fast", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_bas_dyn2", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_dist", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_dist_dyn_medium", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_1", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_1_dyn_normal", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_1_dyn_medium", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_1_dyn_fast", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_2", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_2_dyn_normal", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_2_dyn_medium", actionTime, {type: "controller", controllerType: 123, value: 127});
                        core.dispatch("synth_arp_2_dyn_fast", actionTime, {type: "controller", controllerType: 123, value: 127});
                        break;
                    case "turn":
                        this.dispatchEvent("_external:rotation", {rotation: eventProperties.degrees});

                        if(previousTurnDegree != 50 && Math.abs(eventProperties.degrees-90) > 50) {
                            //console.log("TURNING 50 or more");
                            //console.log("CURRENT SPEED: " + this.currentSpeed);
                            previousTurnDegree = 50;
                        } else if(previousTurnDegree != 40 && Math.abs(eventProperties.degrees-90) > 40 && Math.abs(eventProperties.degrees-90) < 50) {
                            //console.log("TURNING 40");
                            //console.log("CURRENT SPEED: " + this.currentSpeed);
                            previousTurnDegree = 40;
                        } else if(previousTurnDegree != 30 && Math.abs(eventProperties.degrees-90) > 30 && Math.abs(eventProperties.degrees-90) < 40) {
                            //console.log("TURNING 30");
                            //console.log("CURRENT SPEED: " + this.currentSpeed);
                            previousTurnDegree = 30;
                        } else if(previousTurnDegree != 20 && Math.abs(eventProperties.degrees-90) > 20 && Math.abs(eventProperties.degrees-90) < 30) {
                            //console.log("TURNING 20");
                            //console.log("CURRENT SPEED: " + this.currentSpeed);
                            previousTurnDegree = 20;
                        } else if(previousTurnDegree != 10 && Math.abs(eventProperties.degrees-90) > 10 && Math.abs(eventProperties.degrees-90) < 20) {
                            //console.log("TURNING 10");
                            //console.log("CURRENT SPEED: " + this.currentSpeed);
                            previousTurnDegree = 10;
                            //this.dispatchEvent("turn_sync")

                            dontStartSpeedPatternsBecauseWeAreTurning = true;

                            if(this.currentSpeed >= 60) {
                                this.dispatchEvent("fast_2_turn_sync")
                            } else if(this.currentSpeed >= 40) {
                                this.dispatchEvent("fast_1_turn_sync")
                            } else if(this.currentSpeed >= 20) {
                                this.dispatchEvent("medium_turn_sync")
                            } else if(this.currentSpeed < 20) {
                                this.dispatchEvent("normal_turn_sync")
                            }

                        } else if (previousTurnDegree != 0 && Math.abs(eventProperties.degrees-90) < 10){
                            //console.log("STOPPED TURNING");
                            dontStartSpeedPatternsBecauseWeAreTurning = false;
                                //this.dispatchEvent("transpose_3");

                            if(this.currentSpeed >= 60) {
                                this.dispatchEvent("fast_2_first_beat")
                            } else if(this.currentSpeed >= 40) {
                                this.dispatchEvent("fast_1_first_beat")
                            } else if(this.currentSpeed >= 30) {
                                this.dispatchEvent("medium_2_first_beat")
                            } else if(this.currentSpeed >= 20) {
                                this.dispatchEvent("medium_1_first_beat")
                            } else if(this.currentSpeed < 20) {
                                this.dispatchEvent("normal_first_beat_after_turn")
                            }

                            //Start roll
                            //console.log("CB: " + currentBeat)
                            if(currentBeat == 1) {
                                console.log("3 beat");
                                this.dispatchEvent("drumroll_3", currentBeatTime + 521);
                                this.dispatchEvent("do_transpose", currentBeatTime+(521*4)-70);
                            } else if(currentBeat == 2) {
                                //console.log("2 beat");
                                this.dispatchEvent("drumroll_2", currentBeatTime + 521);
                                this.dispatchEvent("do_transpose", currentBeatTime+(521*3)-70);
                            } else if(currentBeat == 3) {
                                //console.log("1 beat");
                                this.dispatchEvent("drumroll_1", currentBeatTime + 521);
                                this.dispatchEvent("do_transpose", currentBeatTime+(521*2)-70);
                            } else {
                                //console.log("TO SHORT FOR ROLL");
                                this.dispatchEvent("do_transpose", currentBeatTime+511);
                            }

                            previousTurnDegree = 0;
                        }

                        this.dispatchEvent("synth_bas_dyn2_bus_macro", time.current, {value: Math.abs(eventProperties.degrees-90)/100});

                        break;
                    case "speed":
                        this.setSpeed(eventProperties.speed);
                        this.setTweenTime(eventProperties.time);

                        //this.dispatchEvent("change_filter", actionTime, {value: eventProperties.speed/100});
                        //console.log("SIFFRA: " + eventProperties.speed/100);
                        break;
                    case "start":
                        if(!bppStarted) {
                            this.dispatchEvent("start_bpp_and_idle_pattern", actionTime);
                            bppStarted = true;
                        } else {
                            console.log("Double start events. Ignoring this")
                        }
                        break;
                        case "stop":
                            this.dispatchEvent("stop_bpp", actionTime);
                            bppStarted = false;
                            break;
                    case "breaking":
                    case "idle":
                    case "normal_speed_from_still":
                    case "normal_speed":
                    case "medium_1_speed":
                    case "medium_2_speed":
                    case "high_1_speed":
                    case "high_2_speed":
                        if(!dontStartSpeedPatternsBecauseWeAreTurning){
                            switch (eventName) {
                                case "breaking":
                                    this.dispatchEvent("idle_sync", actionTime);
                                    break;
                                case "idle":
                                    this.dispatchEvent("idle_sync", actionTime);
                                    break;
                                case "normal_speed_from_still":
                                    this.dispatchEvent("normal_first_beat", actionTime);
                                    break;
                                case "normal_speed":
                                    this.dispatchEvent("normal_sync", actionTime);
                                    break;
                                case "medium_1_speed":
                                    this.dispatchEvent("medium_1_sync", actionTime);
                                    break;
                                case "medium_2_speed":
                                    this.dispatchEvent("medium_2_sync", actionTime);
                                    break;
                                case "high_1_speed":
                                    this.dispatchEvent("fast_1_sync", actionTime);
                                    break;
                                case "high_2_speed":
                                    this.dispatchEvent("fast_2_sync", actionTime);
                                    break;
                            }
                        }
                        break;
                }
            }
        },
        setSpeed: {
            value: function(speed) {
                if(this.currentSpeed > speed) {
                    decrease = true;
                } else {
                    decrease = false;
                }
                targetSpeed = speed;
                speedDifference = Math.abs(this.currentSpeed - targetSpeed);
                if (!tweening) {
                    previousFrameTime = time.current-1;
                    html.raf(updateSpeed.bind(this));
                    tweening = true;
                }
            }
        },
        setTweenTime: {
            value: function(time) {
                this.tweenTime = time;
            }
        }
    });
});
-->

</actions>
